const proffys = [
    {
        name: "Luzinete Correia",
        avatar: "https://avatars2.githubusercontent.com/u/62381724?s=96&v=4",
        whatsapp: "9876543221",
        bio: "I’m currently working on Systems Analyst. I currently learning low platform programming languages for professional growth",
        subject: "Analista",
        cost: "30",
        weekday: [0],
        time_from: [720],
        time_to: [1220]
    },
    {
        name: "Amalua Natureza",
        avatar: "https://github.com/luzicorreia/luzicorreia/edit/master/README.md",
        whatsapp: "9876543221",
        bio: "I’m currently working on Systems Analyst. I currently learning low platform programming languages for professional growth",
        subject: "Decoration",
        cost: "25",
        weekday: [1],
        timi_from: [720],
        time_to: [1220]
    }

]